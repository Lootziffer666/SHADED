# THEIA Spatial Depth Mobile — Bootstrap

Android/Kotlin-Prototyp für eine Mobile-first Bild→Spatial-Experience-Pipeline.

## Bewusste Architekturentscheidung
DA3-Small (80M Parameter, Apache-2.0) ist der einzige DA3-Any-View-Checkpoint, der in einem kommerziellen Produkt direkt in Betracht kommt. Die DA3-Modelle Large/Giant/Nested sind CC BY-NC 4.0; sie dürfen nicht als Produkt-Backend für kommerzielle Nutzung eingeplant werden.

## Aktueller Stand
- Compose-Shell
- deterministische Depth→Height→Normal-Map-Derivation als Startpunkt
- ONNX-Hook als klare Integrationsgrenze
- keine vorgetäuschte, unvalidierte DA3-ONNX-Konvertierung

## Nächste Implementierungsblöcke
1. `GetContent`-Picker + EXIF-Orientierung + Resize auf 384/512 px.
2. DA3-Small exportieren, ONNX numerisch gegen PyTorch validieren und NNAPI/GPU Provider benchmarken.
3. Depth→Normal in Vulkan/AGSL/Compute verlagern.
4. Point cloud aus Intrinsics + depth generieren; GPU-culling/LOD.
5. Remote optional: DA3-Base / Server-Gaussian-Head; Client bleibt lokaler Renderer.

## Kritische Produktregel
Aus einem Einzelbild sind verdeckte Flächen nicht messbar. Markiere erzeugte Rückseiten/Disocclusions als *synthesized*, und halte den Interaktionsraum auf einen vertrauensgewichteten Kameradolly begrenzt.
