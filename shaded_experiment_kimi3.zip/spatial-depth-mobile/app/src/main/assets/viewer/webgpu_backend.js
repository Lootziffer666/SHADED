/**
 * webgpu_backend.js
 * Progressive enhancement: if WebGPU is available, depth→pointcloud
 * runs in a compute shader (multiview.wgsl). Falls back to CPU JS.
 *
 * Usage (called from index.html after loadPointCloud with raw data):
 *   const backend = await WebGPUBackend.create();
 *   const points  = await backend.depthToCloud(depthF32, colorU8, W, H, fov);
 *   window.loadPointCloud({ points });
 */

export class WebGPUBackend {

    static async create() {
        if (!navigator.gpu) return new CpuFallbackBackend();
        try {
            const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
            if (!adapter) return new CpuFallbackBackend();
            const device  = await adapter.requestDevice();
            return new WebGPUBackend(device);
        } catch { return new CpuFallbackBackend(); }
    }

    constructor(device) { this.device = device; this._pipeline = null; }

    async _getOrBuildPipeline() {
        if (this._pipeline) return this._pipeline;
        const wgsl = await fetch('multiview.wgsl').then(r => r.text());
        const mod  = this.device.createShaderModule({ code: wgsl });
        this._pipeline = this.device.createComputePipeline({
            layout: 'auto',
            compute: { module: mod, entryPoint: 'main' }
        });
        return this._pipeline;
    }

    async depthToCloud(depthF32, colorRGBA8, W, H, fovDeg = 60) {
        const device = this.device;
        const pipe   = await this._getOrBuildPipeline();
        const n      = W * H;

        // Upload buffers
        const depthBuf = device.createBuffer({ size: n * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
        device.queue.writeBuffer(depthBuf, 0, depthF32);
        const colorBuf = device.createBuffer({ size: n * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
        device.queue.writeBuffer(colorBuf, 0, colorRGBA8);

        // Output buffer (PointOut: 8 floats per pixel)
        const outBuf = device.createBuffer({ size: n * 8 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC });

        // Params uniform: width, height, fovRad, step
        const paramsArr = new ArrayBuffer(16);
        new Uint32Array(paramsArr, 0, 1)[0]  = W;
        new Uint32Array(paramsArr, 4, 1)[0]  = H;
        new Float32Array(paramsArr, 8, 1)[0] = (fovDeg * Math.PI) / 180;
        new Uint32Array(paramsArr, 12, 1)[0] = Math.max(1, Math.sqrt(n / 100000) | 0);
        const paramsBuf = device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        device.queue.writeBuffer(paramsBuf, 0, paramsArr);

        const bg = device.createBindGroup({
            layout: pipe.getBindGroupLayout(0),
            entries: [
                { binding: 0, resource: { buffer: depthBuf } },
                { binding: 1, resource: { buffer: colorBuf } },
                { binding: 2, resource: { buffer: outBuf   } },
                { binding: 3, resource: { buffer: paramsBuf} },
            ]
        });

        const enc = device.createCommandEncoder();
        const pass = enc.beginComputePass();
        pass.setPipeline(pipe); pass.setBindGroup(0, bg);
        pass.dispatchWorkgroups(Math.ceil(W / 16), Math.ceil(H / 16));
        pass.end();

        // Readback
        const readBuf = device.createBuffer({ size: n * 8 * 4, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
        enc.copyBufferToBuffer(outBuf, 0, readBuf, 0, n * 8 * 4);
        device.queue.submit([enc.finish()]);
        await readBuf.mapAsync(GPUMapMode.READ);
        const mapped = new Float32Array(readBuf.getMappedRange());

        // Decode PointOut structs → viewer format
        const points = [];
        for (let i = 0; i < n; i++) {
            const base = i * 8;
            const confidence = mapped[base + 3];
            if (confidence < 0.02) continue;
            points.push({
                x: mapped[base + 0], y: mapped[base + 1], z: mapped[base + 2],
                r: mapped[base + 4] * 255, g: mapped[base + 5] * 255, b: mapped[base + 6] * 255,
                size: 0.009, alpha: 0.7 + confidence * 0.2,
            });
        }
        readBuf.unmap();
        return points;
    }
}

// CPU fallback – mirrors the WGSL shader logic in plain JS
class CpuFallbackBackend {
    async depthToCloud(depthF32, colorRGBA8, W, H, fovDeg = 60) {
        const fovRad = (fovDeg * Math.PI) / 180;
        const fx = W / (2 * Math.tan(fovRad / 2));
        const fy = H / (2 * Math.tan(fovRad / 2));
        const cx = W / 2, cy = H / 2;
        const step = Math.max(1, Math.sqrt((W * H) / 100000) | 0);
        const pts = [];
        for (let y = 0; y < H; y += step) for (let x = 0; x < W; x += step) {
            const i = y * W + x;
            const d = depthF32[i];
            if (d < 0.02) continue;
            pts.push({
                x: (x - cx) * d / fx, y: (cy - y) * d / fy, z: d,
                r: colorRGBA8[i*4], g: colorRGBA8[i*4+1], b: colorRGBA8[i*4+2],
                size: 0.009, alpha: 0.75,
            });
        }
        return pts;
    }
}
