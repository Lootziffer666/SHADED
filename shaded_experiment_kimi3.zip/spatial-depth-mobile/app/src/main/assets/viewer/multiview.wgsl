// multiview.wgsl – WebGPU compute shader: depth map → world-space point cloud
// Called once per image frame; output is a storage buffer for the render pipeline.

struct PointOut {
  pos   : vec4<f32>,   // xyz = world position, w = depth confidence
  color : vec4<f32>,   // rgba from source image
};

@group(0) @binding(0) var<storage, read>       depthBuf : array<f32>;
@group(0) @binding(1) var<storage, read>       colorBuf : array<u32>;  // RGBA8 packed
@group(0) @binding(2) var<storage, read_write> outBuf   : array<PointOut>;

struct Params {
  width    : u32,
  height   : u32,
  fovRad   : f32,
  step     : u32,    // subsampling step (1 = full, 2 = half, etc.)
};
@group(0) @binding(3) var<uniform> params : Params;

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid : vec3<u32>) {
  let s = params.step;
  let px = gid.x * s;
  let py = gid.y * s;
  if (px >= params.width || py >= params.height) { return; }

  let idx = py * params.width + px;
  let d   = depthBuf[idx];
  if (d < 0.02) { return; }  // skip far background

  let fx  = f32(params.width)  / (2.0 * tan(params.fovRad / 2.0));
  let fy  = f32(params.height) / (2.0 * tan(params.fovRad / 2.0));
  let cx  = f32(params.width)  / 2.0;
  let cy  = f32(params.height) / 2.0;

  let worldX = (f32(px) - cx) * d / fx;
  let worldY = (cy - f32(py)) * d / fy;
  let worldZ = d;

  let packed = colorBuf[idx];
  let r = f32((packed >>  0u) & 0xFFu) / 255.0;
  let g = f32((packed >>  8u) & 0xFFu) / 255.0;
  let b = f32((packed >> 16u) & 0xFFu) / 255.0;

  outBuf[idx] = PointOut(
    vec4<f32>(worldX, worldY, worldZ, d),
    vec4<f32>(r, g, b, 1.0)
  );
}
