#!/bin/bash
# Compile GLSL Compute Shaders to SPIRV, then embed as C headers.
# Requires: glslc (part of Android NDK / Vulkan SDK)
set -e
GLSLC=${ANDROID_NDK}/shader-tools/linux-x86_64/glslc
DIR=$(dirname "$0")

$GLSLC -fshader-stage=comp $DIR/depth_blur.comp     -o $DIR/depth_blur.spv
$GLSLC -fshader-stage=comp $DIR/depth_to_maps.comp  -o $DIR/depth_to_maps.spv

xxd -i $DIR/depth_blur.spv     > ../cpp/depth_blur_spv.h
xxd -i $DIR/depth_to_maps.spv  > ../cpp/depth_to_maps_spv.h
echo "SPIRV compiled and embedded."
