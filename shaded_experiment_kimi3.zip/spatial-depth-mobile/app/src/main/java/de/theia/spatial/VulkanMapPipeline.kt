package de.theia.spatial

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log

class VulkanMapPipeline(private val ctx: Context) {

    internal val nativeAvailable: Boolean = runCatching {
        System.loadLibrary("spatial"); true
    }.getOrDefault(false)

    fun generate(d: DepthResult, fovDegrees: Float = 60f): SpatialMaps {
        if (!nativeAvailable) {
            Log.w(TAG, "Vulkan not available – CPU fallback")
            return MapGenerator.generate(d, fovDegrees)
        }
        return runCatching {
            val raw = runVulkanCompute(d.depth, d.width, d.height)
                ?: throw IllegalStateException("runVulkanCompute returned null")
            decodeMaps(raw, d.width, d.height, d, fovDegrees)
        }.getOrElse {
            Log.e(TAG, "Vulkan error: ${it.message} – CPU fallback")
            MapGenerator.generate(d, fovDegrees)
        }
    }

    /**
     * Decodes the flat float array returned by the JNI layer.
     * Layout: [height W*H*4, normal W*H*4, bump W*H*4, displ W*H*4]
     * Each group is RGBA bytes normalised to [0,1] floats.
     */
    private fun decodeMaps(raw: FloatArray, w: Int, h: Int, d: DepthResult, fov: Float): SpatialMaps {
        val stride = w * h
        fun toBitmap(offset: Int): Bitmap {
            val px = IntArray(stride)
            for (i in 0 until stride) {
                val base = (offset + i) * 4
                px[i] = Color.argb(
                    (raw[base + 3] * 255).toInt().coerceIn(0, 255),
                    (raw[base + 0] * 255).toInt().coerceIn(0, 255),
                    (raw[base + 1] * 255).toInt().coerceIn(0, 255),
                    (raw[base + 2] * 255).toInt().coerceIn(0, 255),
                )
            }
            return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        }
        return SpatialMaps(
            height       = toBitmap(0),
            normal       = toBitmap(stride),
            bump         = toBitmap(stride * 2),
            displacement = toBitmap(stride * 3),
            pointCloud   = MapGenerator.buildPointCloudPublic(d, fov),
        )
    }

    private external fun runVulkanCompute(depth: FloatArray, w: Int, h: Int): FloatArray?

    companion object { private const val TAG = "VulkanMapPipeline" }
}
