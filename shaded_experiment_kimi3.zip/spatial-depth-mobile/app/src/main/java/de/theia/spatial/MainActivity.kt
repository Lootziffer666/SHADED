package de.theia.spatial

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { SpatialDepthApp() } }
}

@Composable fun SpatialDepthApp() {
    val vm: SpatialViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { vm.process(it) }
    }
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("THEIA · Spatial Depth") }) }) { pad ->
            Column(
                Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Primary CTA
                Button(onClick = { picker.launch("image/*") }, Modifier.fillMaxWidth()) {
                    Text("Bild wählen & Experience erzeugen")
                }

                when (val s = state) {
                    is SpatialUiState.Idle    -> Text("Noch kein Bild gewählt.", style = MaterialTheme.typography.bodySmall)
                    is SpatialUiState.Loading -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Depth + Maps werden berechnet …", style = MaterialTheme.typography.bodySmall)
                    }
                    is SpatialUiState.Error   -> Text("Fehler: ${s.msg}", color = MaterialTheme.colorScheme.error)
                    is SpatialUiState.Ready   -> {
                        // Stats row
                        Text(
                            "${s.durationMs} ms · ${s.maps.pointCloud.size} Punkte · ${s.backend}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        // Open viewer
                        Button(onClick = { vm.launchViewer() }, Modifier.fillMaxWidth()) {
                            Text("🌐 3D Viewer öffnen (Gaussian Splats)")
                        }
                        // Map previews
                        MapCard("Height Map",       s.maps.height)
                        MapCard("Normal Map",       s.maps.normal)
                        MapCard("Bump Map",         s.maps.bump)
                        MapCard("Displacement Map", s.maps.displacement)
                    }
                }
            }
        }
    }
}

@Composable private fun MapCard(label: String, bmp: android.graphics.Bitmap) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Image(bmp.asImageBitmap(), label, Modifier.fillMaxWidth().height(200.dp))
        }
    }
}
