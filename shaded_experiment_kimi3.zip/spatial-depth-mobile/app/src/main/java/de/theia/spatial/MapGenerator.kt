package de.theia.spatial

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

data class SpatialMaps(
    val height:       Bitmap,
    val normal:       Bitmap,
    val bump:         Bitmap,         // high-frequency detail only
    val displacement: Bitmap,         // low-frequency base for tessellation
    val pointCloud:   PointCloud,
)

object MapGenerator {

    /** Derive all PBR maps + point cloud from a normalised depth FloatArray [0,1]. */
    fun generate(d: DepthResult, fovDegrees: Float = 60f): SpatialMaps {
        val w = d.width; val h = d.height; val depth = d.depth
        val height  = IntArray(w * h)
        val normal  = IntArray(w * h)
        val bump    = IntArray(w * h)
        val displ   = IntArray(w * h)

        // Gaussian blur σ=3 for low-freq (displacement)
        val lowFreq = gaussianBlur(depth, w, h, sigma = 3f)

        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val dv = depth[i]
            val lv = lowFreq[i]
            val hv = (dv - lv + 1f) / 2f   // remap high-freq to [0,1]

            // Height map = depth
            val g = (dv * 255).toInt().coerceIn(0, 255)
            height[i] = Color.rgb(g, g, g)

            // Sobel gradients for normals
            val dx = sobelX(depth, w, h, x, y)
            val dy = sobelY(depth, w, h, x, y)
            val nx = ((-dx * 0.5f + 0.5f) * 255).toInt().coerceIn(0, 255)
            val ny = ((-dy * 0.5f + 0.5f) * 255).toInt().coerceIn(0, 255)
            normal[i] = Color.rgb(nx, ny, 255)

            // Bump = high-freq only
            val bv = (hv * 255).toInt().coerceIn(0, 255)
            bump[i] = Color.rgb(bv, bv, bv)

            // Displacement = low-freq
            val lvi = (lv * 255).toInt().coerceIn(0, 255)
            displ[i] = Color.rgb(lvi, lvi, lvi)
        }

        val pc = buildPointCloud(depth, w, h, fovDegrees)

        return SpatialMaps(
            height       = Bitmap.createBitmap(height, w, h, Bitmap.Config.ARGB_8888),
            normal       = Bitmap.createBitmap(normal, w, h, Bitmap.Config.ARGB_8888),
            bump         = Bitmap.createBitmap(bump,   w, h, Bitmap.Config.ARGB_8888),
            displacement = Bitmap.createBitmap(displ,  w, h, Bitmap.Config.ARGB_8888),
            pointCloud   = pc,
        )
    }

    // ── Point cloud via back-projection ──────────────────────────────────
    fun buildPointCloudPublic(d: DepthResult, fovDeg: Float) = buildPointCloud(d.depth, d.width, d.height, fovDeg)
        private fun buildPointCloud(depth: FloatArray, w: Int, h: Int, fovDeg: Float): PointCloud {
        val fovRad = Math.toRadians(fovDeg.toDouble()).toFloat()
        val fx = w / (2f * tan(fovRad / 2f))
        val fy = fx
        val cx = w / 2f; val cy = h / 2f
        // Subsample to max 100k points for mobile
        val step = maxOf(1, sqrt((w * h / 100_000f)).toInt())
        val pts = mutableListOf<Float3>()
        for (y in 0 until h step step) for (x in 0 until w step step) {
            val z = depth[y * w + x]
            if (z < 0.02f) continue   // skip background
            pts += Float3((x - cx) * z / fx, (cy - y) * z / fy, z)
        }
        return PointCloud(pts)
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private fun sobelX(d: FloatArray, w: Int, h: Int, x: Int, y: Int): Float {
        val r = (x + 1).coerceAtMost(w - 1); val l = (x - 1).coerceAtLeast(0)
        val t = (y - 1).coerceAtLeast(0);     val b = (y + 1).coerceAtMost(h - 1)
        return -d[t*w+l] - 2*d[y*w+l] - d[b*w+l] + d[t*w+r] + 2*d[y*w+r] + d[b*w+r]
    }
    private fun sobelY(d: FloatArray, w: Int, h: Int, x: Int, y: Int): Float {
        val r = (x + 1).coerceAtMost(w - 1); val l = (x - 1).coerceAtLeast(0)
        val t = (y - 1).coerceAtLeast(0);     val b = (y + 1).coerceAtMost(h - 1)
        return d[t*w+l] + 2*d[t*w+x] + d[t*w+r] - d[b*w+l] - 2*d[b*w+x] - d[b*w+r]
    }
    private fun gaussianBlur(src: FloatArray, w: Int, h: Int, sigma: Float): FloatArray {
        val radius = (3 * sigma).toInt(); val size = 2 * radius + 1
        val kernel = FloatArray(size) { i -> exp(-((i - radius) * (i - radius)) / (2 * sigma * sigma)).toFloat() }
            .let { k -> val s = k.sum(); FloatArray(k.size) { k[it] / s } }
        val tmp = FloatArray(w * h)
        // Horizontal pass
        for (y in 0 until h) for (x in 0 until w) {
            var acc = 0f
            for (k in kernel.indices) { val sx = (x + k - radius).coerceIn(0, w - 1); acc += src[y * w + sx] * kernel[k] }
            tmp[y * w + x] = acc
        }
        val out = FloatArray(w * h)
        // Vertical pass
        for (y in 0 until h) for (x in 0 until w) {
            var acc = 0f
            for (k in kernel.indices) { val sy = (y + k - radius).coerceIn(0, h - 1); acc += tmp[sy * w + x] * kernel[k] }
            out[y * w + x] = acc
        }
        return out
    }
}

data class Float3(val x: Float, val y: Float, val z: Float)
data class PointCloud(val points: List<Float3>) {
    val size get() = points.size
}
