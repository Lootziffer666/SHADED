package de.theia.spatial

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlin.math.min

object ImageLoader {
    /** Load, EXIF-correct, and resize to at most [maxSide] px (long edge). */
    fun loadAndPrepare(ctx: Context, uri: Uri, maxSide: Int = 512): Bitmap {
        val raw = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
        val exif = ctx.contentResolver.openInputStream(uri)!!.use { ExifInterface(it) }
        val corrected = applyExifRotation(raw, exif)
        return scaleTo(corrected, maxSide)
    }

    private fun applyExifRotation(bmp: Bitmap, exif: ExifInterface): Bitmap {
        val angle = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90  -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (angle == 0f) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(angle) }, true)
    }

    private fun scaleTo(bmp: Bitmap, maxSide: Int): Bitmap {
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat()
        if (scale >= 1f) return bmp
        val w = (bmp.width * scale).toInt()
        val h = (bmp.height * scale).toInt()
        return Bitmap.createScaledBitmap(bmp, w, h, true)
    }

    /** Convert Bitmap → NCHW float32 array normalised to ImageNet stats (DA3 default). */
    fun toNchw(bmp: Bitmap): FloatArray {
        val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
        val std  = floatArrayOf(0.229f, 0.224f, 0.225f)
        val w = bmp.width; val h = bmp.height
        val buf = FloatArray(3 * w * h)
        val px  = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val r = ((c shr 16 and 0xFF) / 255f - mean[0]) / std[0]
            val g = ((c shr  8 and 0xFF) / 255f - mean[1]) / std[1]
            val b = ((c        and 0xFF) / 255f - mean[2]) / std[2]
            buf[0 * w * h + i] = r
            buf[1 * w * h + i] = g
            buf[2 * w * h + i] = b
        }
        return buf
    }
}
