package de.theia.spatial

import ai.onnxruntime.*
import android.content.Context
import android.graphics.Bitmap
import java.nio.FloatBuffer

/**
 * Wraps DA3-Small exported to ONNX.
 *
 * EXPORT INSTRUCTIONS (run once, offline):
 *   pip install onnx onnxruntime torch
 *   python -c "
 *   import torch, onnx
 *   from depth_anything_v3.dpt import DepthAnythingV3
 *   model = DepthAnythingV3({'encoder':'vits','features':64,'out_channels':[48,96,192,384]})
 *   model.load_state_dict(torch.load('da3-small.pth', map_location='cpu')['model'])
 *   model.eval()
 *   dummy = torch.randn(1,3,518,518)
 *   torch.onnx.export(model, dummy, 'da3-small.onnx',
 *       input_names=['image'], output_names=['depth'],
 *       dynamic_axes={'image':{2:'h',3:'w'},'depth':{2:'h',3:'w'}},
 *       opset_version=17)
 *   "
 *
 * VALIDATE before shipping:
 *   python export/validate_onnx.py --pytorch da3-small.pth --onnx da3-small.onnx
 *
 * Place da3-small.onnx in app/src/main/assets/models/
 */
class DepthProvider(ctx: Context) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val opts = OrtSession.SessionOptions().apply {
            addNnapi()        // NNAPI on Android >= 9; falls back to CPU automatically
            setIntraOpNumThreads(4)
            setInterOpNumThreads(2)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val bytes = ctx.assets.open("models/da3-small.onnx").readBytes()
        session = env.createSession(bytes, opts)
    }

    /**
     * Run depth inference on a prepared [Bitmap].
     * Returns a FloatArray of shape [H * W] with relative depth in [0, 1].
     */
    fun infer(bmp: Bitmap): DepthResult {
        val nchw = ImageLoader.toNchw(bmp)
        val shape = longArrayOf(1, 3, bmp.height.toLong(), bmp.width.toLong())
        val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(nchw), shape)
        val out = session.run(mapOf("image" to tensor))
        val raw = (out[0].value as Array<*>)[0] as Array<*> // [H][W]
        val h = bmp.height; val w = bmp.width
        val flat = FloatArray(h * w)
        var min = Float.MAX_VALUE; var max = Float.MIN_VALUE
        for (y in 0 until h) {
            val row = raw[y] as FloatArray
            for (x in 0 until w) { flat[y * w + x] = row[x]; if (row[x] < min) min = row[x]; if (row[x] > max) max = row[x] }
        }
        val range = (max - min).coerceAtLeast(1e-6f)
        for (i in flat.indices) flat[i] = (flat[i] - min) / range
        return DepthResult(flat, w, h)
    }

    override fun close() { session.close(); env.close() }
}

data class DepthResult(val depth: FloatArray, val width: Int, val height: Int)
