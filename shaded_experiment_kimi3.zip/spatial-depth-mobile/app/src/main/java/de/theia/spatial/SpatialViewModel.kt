package de.theia.spatial

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class SpatialUiState {
    object Idle    : SpatialUiState()
    object Loading : SpatialUiState()
    data class Ready(val maps: SpatialMaps, val durationMs: Long, val backend: String) : SpatialUiState()
    data class Error(val msg: String)  : SpatialUiState()
}

class SpatialViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow<SpatialUiState>(SpatialUiState.Idle)
    val state = _state.asStateFlow()

    fun process(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        _state.value = SpatialUiState.Loading
        runCatching {
            val ctx = getApplication<Application>()
            val t0  = System.currentTimeMillis()

            // 1. Load + EXIF correct
            val bmp = ImageLoader.loadAndPrepare(ctx, uri, maxSide = 512)

            // 2. Depth inference (ONNX/NNAPI or luminance fallback)
            val (depthResult, depthBackend) = runCatching {
                DepthProvider(ctx).use { it.infer(bmp) } to "DA3-ONNX/NNAPI"
            }.getOrElse {
                val nchw = ImageLoader.toNchw(bmp)
                val lum  = FloatArray(bmp.width * bmp.height) { i ->
                    val r = nchw[i]; val g = nchw[bmp.width*bmp.height+i]; val b = nchw[2*bmp.width*bmp.height+i]
                    ((0.299f*r + 0.587f*g + 0.114f*b) + 1f) / 2f
                }
                DepthResult(lum, bmp.width, bmp.height) to "Luminance-CPU"
            }

            // 3. GPU map generation (Vulkan or CPU fallback)
            val pipeline = VulkanMapPipeline(ctx)
            val maps = pipeline.generate(depthResult)
            val mapBackend = if (pipeline.nativeAvailable) "Vulkan-Compute" else "CPU-Kotlin"

            val backend = "$depthBackend + $mapBackend"
            SpatialUiState.Ready(maps, System.currentTimeMillis() - t0, backend)
        }.fold(
            onSuccess = { _state.value = it },
            onFailure = { _state.value = SpatialUiState.Error(it.message ?: "Unbekannter Fehler") }
        )
    }

    /** Launch the Three.js/WebGPU spatial viewer with the current point cloud. */
    fun launchViewer() {
        val s = _state.value as? SpatialUiState.Ready ?: return
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, SpatialViewerActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("pointcloud_json", s.maps.pointCloud.toJson())
        }
        ctx.startActivity(intent)
    }
}
