package de.theia.spatial

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Hosts the Three.js Gaussian Splat Viewer in a WebView.
 * Receives a PointCloud via Intent extras and pushes it into the viewer via JS bridge.
 *
 * Launch from SpatialViewModel:
 *   val intent = Intent(ctx, SpatialViewerActivity::class.java)
 *   intent.putExtra("pointcloud_json", pc.toJson())
 *   ctx.startActivity(intent)
 */
class SpatialViewerActivity : ComponentActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).also { setContentView(it) }

        webView.settings.apply {
            javaScriptEnabled = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            mediaPlaybackRequiresUserGesture = false
        }
        webView.addJavascriptInterface(PointCloudBridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                // Push point cloud JSON after page load
                val json = intent.getStringExtra("pointcloud_json") ?: return
                webView.evaluateJavascript("window.loadPointCloud($json);", null)
            }
        }
        webView.loadUrl("file:///android_asset/viewer/index.html")
    }

    inner class PointCloudBridge {
        @JavascriptInterface
        fun getVersion(): String = "THEIA Spatial Viewer 0.2"
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

/** Serialise PointCloud to the JSON format expected by the viewer. */
fun PointCloud.toJson(): String {
    val arr = JSONArray()
    points.forEach { p ->
        arr.put(JSONObject().apply {
            put("x", p.x); put("y", p.y); put("z", p.z)
            put("r", 180); put("g", 160); put("b", 220)
            put("size", 0.010); put("alpha", 0.80)
        })
    }
    return JSONObject().put("points", arr).toString()
}
