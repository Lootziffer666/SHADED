// Run via Android instrumentation test or as a standalone Kotlin script on device.
// Reports: load time, p50/p95/p99 inference latency, memory delta.
package de.theia.spatial.bench

import ai.onnxruntime.*
import android.content.Context
import java.nio.FloatBuffer

class BenchmarkRunner(private val ctx: Context) {

    data class BenchResult(val loadMs: Long, val p50: Long, val p95: Long, val p99: Long, val memKb: Long)

    fun run(assetPath: String = "models/da3-small.onnx", warmup: Int = 3, runs: Int = 20): BenchResult {
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            addNnapi(); setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val t0 = System.currentTimeMillis()
        val bytes = ctx.assets.open(assetPath).readBytes()
        val session = env.createSession(bytes, opts)
        val loadMs = System.currentTimeMillis() - t0

        val dummy = FloatBuffer.wrap(FloatArray(3 * 518 * 518) { 0.5f })
        val shape = longArrayOf(1, 3, 518, 518)

        // Warmup
        repeat(warmup) {
            val t = OnnxTensor.createTensor(env, dummy.rewind() as FloatBuffer, shape)
            session.run(mapOf("image" to t)).close(); t.close()
        }

        val latencies = LongArray(runs)
        val rt = Runtime.getRuntime()
        val memBefore = rt.totalMemory() - rt.freeMemory()
        for (i in 0 until runs) {
            val t = OnnxTensor.createTensor(env, dummy.rewind() as FloatBuffer, shape)
            val ts = System.currentTimeMillis()
            session.run(mapOf("image" to t)).close(); t.close()
            latencies[i] = System.currentTimeMillis() - ts
        }
        val memAfter = rt.totalMemory() - rt.freeMemory()
        latencies.sort()

        session.close(); env.close()
        return BenchResult(
            loadMs = loadMs,
            p50    = latencies[runs / 2],
            p95    = latencies[(runs * 0.95).toInt()],
            p99    = latencies[(runs * 0.99).toInt()],
            memKb  = (memAfter - memBefore) / 1024,
        )
    }
}
