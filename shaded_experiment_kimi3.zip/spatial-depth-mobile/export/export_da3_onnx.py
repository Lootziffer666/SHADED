"""
Export DA3-Small to ONNX, then quantise to INT8 for NNAPI.
Usage:
    python export/export_da3_onnx.py --checkpoint da3-small.pth --out app/src/main/assets/models/

Requirements:
    pip install torch onnx onnxruntime onnxruntime-tools
"""
import argparse, pathlib, torch
from depth_anything_v3.dpt import DepthAnythingV3

CFG = {"encoder": "vits", "features": 64, "out_channels": [48, 96, 192, 384]}

def export(pth: str, out_dir: str):
    out = pathlib.Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    model = DepthAnythingV3(CFG)
    model.load_state_dict(torch.load(pth, map_location="cpu")["model"])
    model.eval()

    dummy = torch.randn(1, 3, 518, 518)
    onnx_path = out / "da3-small.onnx"
    torch.onnx.export(
        model, dummy, str(onnx_path),
        input_names=["image"], output_names=["depth"],
        dynamic_axes={"image": {2: "h", 3: "w"}, "depth": {2: "h", 3: "w"}},
        opset_version=17,
    )
    print(f"Exported ONNX: {onnx_path}")

    # INT8 static quantisation (NNAPI-compatible subset)
    try:
        from onnxruntime.quantization import quantize_static, CalibrationDataReader, QuantType
        class FakeCal(CalibrationDataReader):
            def __init__(self): self.done = False
            def get_next(self):
                if self.done: return None
                self.done = True
                return {"image": torch.randn(1, 3, 518, 518).numpy()}
        int8_path = out / "da3-small-int8.onnx"
        quantize_static(str(onnx_path), str(int8_path), FakeCal(), weight_type=QuantType.QInt8)
        print(f"INT8 model: {int8_path}")
    except Exception as e:
        print(f"INT8 quantisation skipped: {e}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--out", default="app/src/main/assets/models/")
    args = ap.parse_args()
    export(args.checkpoint, args.out)
