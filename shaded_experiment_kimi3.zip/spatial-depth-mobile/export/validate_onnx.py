"""
Validate DA3-Small ONNX export against PyTorch reference.
Usage:
    python export/validate_onnx.py --pytorch da3-small.pth --onnx da3-small.onnx

Expects depth_anything_v3 package installed and on PYTHONPATH.
"""
import argparse
import numpy as np
import torch
import onnxruntime as ort
from depth_anything_v3.dpt import DepthAnythingV3

def load_pytorch(pth_path: str):
    model = DepthAnythingV3({"encoder": "vits", "features": 64, "out_channels": [48, 96, 192, 384]})
    model.load_state_dict(torch.load(pth_path, map_location="cpu")["model"])
    model.eval()
    return model

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--pytorch", required=True)
    p.add_argument("--onnx",    required=True)
    p.add_argument("--size",    type=int, default=518)
    p.add_argument("--atol",    type=float, default=1e-4)
    args = p.parse_args()

    dummy = torch.randn(1, 3, args.size, args.size)

    model = load_pytorch(args.pytorch)
    with torch.no_grad():
        pt_out = model(dummy).cpu().numpy()

    sess = ort.InferenceSession(args.onnx, providers=["CPUExecutionProvider"])
    ort_out = sess.run(None, {"image": dummy.numpy()})[0]

    max_err = np.abs(pt_out - ort_out).max()
    mean_err = np.abs(pt_out - ort_out).mean()
    print(f"Max |error|  = {max_err:.6f}  (atol {args.atol})")
    print(f"Mean |error| = {mean_err:.6f}")
    assert max_err < args.atol, "ONNX export FAILED tolerance check!"
    print("ONNX export OK")

if __name__ == "__main__":
    main()
