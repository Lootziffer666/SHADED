import * as THREE from 'three';
import { ShadedWorldState } from './ShadedWorldState.js';
import { ShadedHydrology } from './ShadedHydrology.js';
import { ShadedWeather } from './ShadedWeather.js';
import { ShadedSeasons } from './ShadedSeasons.js';
import { ShadedMaterialBehavior } from './ShadedMaterialBehavior.js';
import { ShadedInteraction } from './ShadedInteraction.js';
import { ShadedInspection, LENS_MODES } from './ShadedInspection.js';
import { ShadedNarrative } from './ShadedNarrative.js';

export class ShadedOrchestrator {
  constructor(scene, camera, renderer, composer) {
    this.scene = scene; this.camera = camera; this.renderer = renderer; this.composer = composer;
    this.world = new ShadedWorldState();
    this.hydrology = new ShadedHydrology(scene, this.world);
    this.weather = new ShadedWeather(scene, this.world);
    this.seasons = new ShadedSeasons(scene, this.world);
    this.materials = new ShadedMaterialBehavior(scene, this.world);
    this.interaction = new ShadedInteraction(scene, this.world, this.materials);
    this.inspection = new ShadedInspection(composer, this.world);
    this.narrative = new ShadedNarrative(scene, camera, renderer, this.world);
    this.timeScale = 1.0;
    this.autoAdvanceTime = false;
  }
  scanScene() {
    this.scene.traverse(child => {
      if (!child.isMesh || !child.material) return;
      const name = child.name.toLowerCase();
      let type = 'generic';
      if (name.includes('boden') || name.includes('floor') || name.includes('ground')) type = 'floor';
      else if (name.includes('grass') || name.includes('rasen')) type = 'grass';
      else if (name.includes('asphalt') || name.includes('weg')) type = 'asphalt';
      else if (name.includes('wand') || name.includes('wall')) type = 'concrete';
      else if (name.includes('holz') || name.includes('wood') || name.includes('bench')) type = 'wood';
      else if (name.includes('metal') || name.includes('chrome') || name.includes('aluminium')) type = 'metal';
      else if (name.includes('cardboard') || name.includes('pappe')) type = 'cardboard';
      else if (name.includes('banner') || name.includes('stoff')) type = 'banner';
      else if (name.includes('led') || name.includes('screen')) type = 'led';
      else if (name.includes('baum') || name.includes('tree')) type = 'tree';
      this.materials.registerMesh(child, type);
      if (type === 'tree' || type === 'banner') {
        child.userData.windSway = { speed: 1 + Math.random(), amplitude: type === 'tree' ? 0.05 : 0.15, phase: Math.random() * Math.PI * 2 };
      }
      if (type === 'tree' || type === 'grass') {
        child.userData.seasonalTint = { base: child.material.color.clone(), autumn: new THREE.Color(type === 'tree' ? 0xcc6622 : 0x8b6914) };
      }
    });
  }
  update(delta, time) {
    const scaledDelta = delta * this.timeScale;
    if (this.autoAdvanceTime) {
      const newTime = (this.world.get('timeOfDay') + scaledDelta * 0.5) % 24;
      this.world.set('timeOfDay', newTime);
    }
    this.hydrology.update(scaledDelta, time);
    this.weather.update(scaledDelta, time);
    this.seasons.update(scaledDelta, time);
    this.materials.update(scaledDelta, time);
    this.interaction.update(scaledDelta, time);
    this.inspection.update(time);
    this.narrative.update(scaledDelta);
  }
  onPlayerMove(position, isSprinting) { this.interaction.onPlayerMove(position, isSprinting); }
  setLens(mode) { this.inspection.setLens(mode); }
  setState(key, value) { this.world.set(key, value); }
  getState(key) { return this.world.get(key); }
  addKeyframe(t, p) { this.narrative.addKeyframe(t, p); }
  playStoryboard() { this.narrative.playStoryboard(); }
  stopStoryboard() { this.narrative.stopStoryboard(); }
  showDialog(t, d) { this.narrative.showDialog(t, d); }
  capturePNG() { return this.narrative.capturePNG(); }
  startRecording() { this.narrative.startRecording(); }
  stopRecording() { this.narrative.stopRecording(); }
  dispose() {
    this.hydrology.dispose(); this.weather.dispose(); this.seasons.dispose();
    this.materials.dispose(); this.interaction.dispose(); this.inspection.dispose(); this.narrative.dispose();
  }
}

export { LENS_MODES };
