import * as THREE from 'three';

export class ShadedMaterialBehavior {
  constructor(scene, worldState) {
    this.scene = scene;
    this.world = worldState;
    this.trackedMaterials = new Map();
    this.footprintDecals = [];
    this.scorchMarks = [];
  }
  registerMesh(mesh, materialType) {
    if (!mesh.material) return;
    const key = mesh.uuid;
    if (this.trackedMaterials.has(key)) return;
    const originalColor = mesh.material.color ? mesh.material.color.clone() : new THREE.Color(0xffffff);
    this.trackedMaterials.set(key, { mesh, type: materialType, originalColor, wear: 0, wetness: 0, scorch: 0, moss: 0 });
  }
  update(delta, time) {
    const temp = this.world.get('temperature');
    const wear = this.world.get('wear');
    const humidity = this.world.get('humidity');
    const pollution = this.world.get('pollution');
    this.trackedMaterials.forEach(data => {
      const mat = data.mesh.material;
      if (!mat) return;
      const targetWetness = this.world.wetnessFor(data.type);
      data.wetness += (targetWetness - data.wetness) * delta * 2;
      const targetDecay = this.world.decayFor(data.type);
      data.wear = Math.max(data.wear, targetDecay);
      if (mat.color) {
        const wetDarken = 1 - data.wetness * 0.3;
        const wearFade = 1 - data.wear * 0.4;
        const pollutionGray = 1 - pollution * 0.3;
        mat.color.copy(data.originalColor).multiplyScalar(wetDarken * wearFade * pollutionGray);
      }
      if (mat.roughness !== undefined) {
        const baseRoughness = data.type === 'floor' ? 0.2 : 0.5;
        mat.roughness = baseRoughness + data.wetness * 0.3 + data.wear * 0.4;
      }
      if ((data.type === 'metal' || data.type === 'chrome') && mat.color) {
        const rust = data.wear * humidity;
        if (rust > 0.1) mat.color.lerp(new THREE.Color(0x8b4513), rust * 0.5);
      }
      if ((data.type === 'wood' || data.type === 'benchWood') && mat.color) {
        const rot = data.wear * humidity * 2;
        if (rot > 0.2) mat.color.lerp(new THREE.Color(0x5c4033), Math.min(1, rot));
      }
      if (humidity > 0.7 && data.wear > 0.3) {
        data.moss = Math.min(1, data.moss + delta * 0.01);
        if (mat.color) mat.color.lerp(new THREE.Color(0x2d5a1e), data.moss * 0.3);
      }
      if (this.world.get('eventPhase') === 'closed' && data.wear > 0.5) {
        data.scorch = Math.min(1, data.scorch + delta * 0.005);
        if (mat.color) mat.color.lerp(new THREE.Color(0x1a1a1a), data.scorch * 0.3);
      }
    });
  }
  addFootprint(x, z, intensity = 1) {
    const decalGeom = new THREE.PlaneGeometry(0.3, 0.15);
    const decalMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.15 * intensity, depthWrite: false });
    const decal = new THREE.Mesh(decalGeom, decalMat);
    decal.position.set(x, 0.01, z);
    decal.rotation.x = -Math.PI / 2;
    decal.rotation.z = Math.random() * Math.PI;
    this.scene.add(decal);
    this.footprintDecals.push({ mesh: decal, life: 30 });
  }
  addScorchMark(x, z, radius = 1) {
    const geom = new THREE.CircleGeometry(radius, 16);
    const mat = new THREE.MeshBasicMaterial({ color: 0x0a0a0a, transparent: true, opacity: 0.6, depthWrite: false });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(x, 0.02, z);
    mesh.rotation.x = -Math.PI / 2;
    this.scene.add(mesh);
    this.scorchMarks.push(mesh);
  }
  updateDecals(delta) {
    for (let i = this.footprintDecals.length - 1; i >= 0; i--) {
      const d = this.footprintDecals[i];
      d.life -= delta;
      d.mesh.material.opacity *= 0.995;
      if (d.life <= 0) {
        this.scene.remove(d.mesh); d.mesh.geometry.dispose(); d.mesh.material.dispose();
        this.footprintDecals.splice(i, 1);
      }
    }
  }
  dispose() {
    this.footprintDecals.forEach(d => { this.scene.remove(d.mesh); d.mesh.geometry.dispose(); d.mesh.material.dispose(); });
    this.scorchMarks.forEach(m => { this.scene.remove(m); m.geometry.dispose(); m.material.dispose(); });
  }
}
