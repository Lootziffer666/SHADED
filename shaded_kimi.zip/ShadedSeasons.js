import * as THREE from 'three';

export class ShadedSeasons {
  constructor(scene, worldState) {
    this.scene = scene;
    this.world = worldState;
    this.snowAccumulation = 0;
    this.initSnowSystem();
  }
  initSnowSystem() {
    const count = 3000;
    const geom = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 120;
      positions[i * 3 + 1] = 15 + Math.random() * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 120;
    }
    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.snowGeom = geom;
    this.snowMesh = new THREE.Points(geom, new THREE.PointsMaterial({
      color: 0xffffff, size: 0.08, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true
    }));
    this.scene.add(this.snowMesh);
  }
  update(delta, time) {
    const day = this.world.get('dayOfYear');
    const temp = this.world.get('temperature');
    const weather = this.world.get('weather');
    const isSnowing = weather === 'snow' && temp < 2;
    this.snowMesh.material.opacity = isSnowing ? 0.8 : 0;
    if (isSnowing) {
      const pos = this.snowGeom.attributes.position.array;
      for (let i = 0; i < pos.length / 3; i++) {
        pos[i * 3 + 1] -= delta * (1 + Math.random());
        pos[i * 3] += Math.sin(time + i) * 0.01;
        if (pos[i * 3 + 1] < 0) {
          pos[i * 3 + 1] = 15 + Math.random() * 10;
          pos[i * 3] = (Math.random() - 0.5) * 120;
          pos[i * 3 + 2] = (Math.random() - 0.5) * 120;
        }
      }
      this.snowGeom.attributes.position.needsUpdate = true;
      this.snowAccumulation = Math.min(1, this.snowAccumulation + delta * 0.05);
    } else if (temp > 5) {
      this.snowAccumulation = Math.max(0, this.snowAccumulation - delta * 0.1);
    }
    const autumnProgress = Math.max(0, Math.min(1, (day - 240) / 60));
    this.scene.traverse(child => {
      if (child.userData?.seasonalTint && child.material) {
        const base = child.userData.seasonalTint.base;
        const autumn = child.userData.seasonalTint.autumn;
        child.material.color.lerpColors(base, autumn, autumnProgress * 0.7);
      }
    });
  }
  dispose() {
    this.scene.remove(this.snowMesh); this.snowGeom.dispose(); this.snowMesh.material.dispose();
  }
}
