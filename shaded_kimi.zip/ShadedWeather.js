import * as THREE from 'three';

export class ShadedWeather {
  constructor(scene, worldState) {
    this.scene = scene;
    this.world = worldState;
    this.lightningLight = null;
    this.lightningTimer = 0;
    this.nextLightning = 5 + Math.random() * 10;
    this.smokeLayers = [];
    this.initLightning();
    this.initSmoke();
  }
  initLightning() {
    this.lightningLight = new THREE.PointLight(0xffffff, 0, 200);
    this.lightningLight.position.set(0, 40, 0);
    this.scene.add(this.lightningLight);
  }
  initSmoke() {
    for (let i = 0; i < 3; i++) {
      const geom = new THREE.BufferGeometry();
      const count = 200;
      const pos = new Float32Array(count * 3);
      for (let j = 0; j < count; j++) {
        pos[j * 3] = (Math.random() - 0.5) * 20;
        pos[j * 3 + 1] = Math.random() * 3;
        pos[j * 3 + 2] = (Math.random() - 0.5) * 20;
      }
      geom.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        color: 0x888888, size: 0.3, transparent: true, opacity: 0.15,
        blending: THREE.NormalBlending, depthWrite: false, sizeAttenuation: true
      });
      const mesh = new THREE.Points(geom, mat);
      mesh.position.set(20 + i * 5, 0, 10);
      this.scene.add(mesh);
      this.smokeLayers.push({ mesh, speed: 0.2 + Math.random() * 0.3 });
    }
  }
  update(delta, time) {
    const weather = this.world.get('weather');
    const wind = this.world.get('windSpeed');
    const humidity = this.world.get('humidity');
    if (weather === 'fog') this.targetFogDensity = 0.06;
    else if (weather === 'rain') this.targetFogDensity = 0.035;
    else if (weather === 'storm') this.targetFogDensity = 0.02;
    else this.targetFogDensity = 0.015 + humidity * 0.01;
    this.currentFogDensity += (this.targetFogDensity - this.currentFogDensity) * delta * 0.5;
    if (this.scene.fog) this.scene.fog.density = this.currentFogDensity;
    if (weather === 'storm') {
      this.lightningTimer += delta;
      if (this.lightningTimer >= this.nextLightning) {
        this.triggerLightning();
        this.lightningTimer = 0;
        this.nextLightning = 2 + Math.random() * 8;
      }
    }
    if (this.lightningLight.intensity > 0) {
      this.lightningLight.intensity *= Math.pow(0.1, delta * 10);
      if (this.lightningLight.intensity < 0.1) this.lightningLight.intensity = 0;
    }
    this.smokeLayers.forEach(layer => {
      const pos = layer.mesh.geometry.attributes.position.array;
      for (let i = 0; i < pos.length / 3; i++) {
        pos[i * 3 + 1] += layer.speed * delta;
        pos[i * 3] += Math.sin(time + i) * 0.01 * wind;
        if (pos[i * 3 + 1] > 5) {
          pos[i * 3 + 1] = 0;
          pos[i * 3] = (Math.random() - 0.5) * 20;
          pos[i * 3 + 2] = (Math.random() - 0.5) * 20;
        }
      }
      layer.mesh.geometry.attributes.position.needsUpdate = true;
      layer.mesh.material.opacity = 0.1 + this.world.get('pollution') * 0.2;
    });
    this.scene.traverse(child => {
      if (child.userData?.windSway) {
        const sway = child.userData.windSway;
        child.rotation.z = Math.sin(time * sway.speed + sway.phase) * sway.amplitude * (wind / 10);
      }
    });
  }
  triggerLightning() {
    this.lightningLight.intensity = 80 + Math.random() * 40;
    this.lightningLight.position.set((Math.random() - 0.5) * 60, 30 + Math.random() * 20, (Math.random() - 0.5) * 60);
    setTimeout(() => {
      if (this.lightningLight) {
        this.lightningLight.intensity = 40 + Math.random() * 20;
        this.lightningLight.position.x += (Math.random() - 0.5) * 10;
      }
    }, 80 + Math.random() * 120);
  }
  dispose() {
    this.scene.remove(this.lightningLight);
    this.smokeLayers.forEach(l => { this.scene.remove(l.mesh); l.mesh.geometry.dispose(); l.mesh.material.dispose(); });
  }
}
