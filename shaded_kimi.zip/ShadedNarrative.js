import * as THREE from 'three';

export class ShadedNarrative {
  constructor(scene, camera, renderer, worldState) {
    this.scene = scene; this.camera = camera; this.renderer = renderer; this.world = worldState;
    this.storyboard = []; this.currentKeyframe = 0; this.isPlaying = false; this.playTime = 0;
    this.dialogElement = null; this.mediaRecorder = null; this.recordedChunks = [];
  }
  addKeyframe(timeOffset, params) {
    this.storyboard.push({ time: timeOffset, params });
    this.storyboard.sort((a, b) => a.time - b.time);
  }
  playStoryboard() { this.isPlaying = true; this.playTime = 0; this.currentKeyframe = 0; }
  stopStoryboard() { this.isPlaying = false; }
  update(delta) {
    if (!this.isPlaying || this.storyboard.length === 0) return;
    this.playTime += delta;
    while (this.currentKeyframe < this.storyboard.length && this.storyboard[this.currentKeyframe].time <= this.playTime) {
      this.applyParams(this.storyboard[this.currentKeyframe].params);
      this.currentKeyframe++;
    }
    if (this.currentKeyframe >= this.storyboard.length) { this.playTime = 0; this.currentKeyframe = 0; }
  }
  applyParams(params) {
    if (params.timeOfDay !== undefined) this.world.set('timeOfDay', params.timeOfDay);
    if (params.weather !== undefined) this.world.set('weather', params.weather);
    if (params.blessing !== undefined) this.world.set('blessing', params.blessing);
    if (params.cameraPos) this.camera.position.set(params.cameraPos.x, params.cameraPos.y, params.cameraPos.z);
    if (params.cameraLookAt) this.camera.lookAt(params.cameraLookAt.x, params.cameraLookAt.y, params.cameraLookAt.z);
  }
  showDialog(text, duration = 3) {
    if (!this.dialogElement) {
      this.dialogElement = document.createElement('div');
      this.dialogElement.className = 'shaded-dialog';
      this.dialogElement.style.cssText = `position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.75);color:#fff;padding:12px 24px;border-radius:8px;font-family:monospace;font-size:14px;pointer-events:none;z-index:1000;max-width:600px;border:1px solid rgba(255,255,255,0.2);`;
      document.body.appendChild(this.dialogElement);
    }
    let index = 0;
    this.dialogElement.textContent = '';
    this.dialogElement.style.opacity = '1';
    const typeInterval = setInterval(() => {
      if (index < text.length) { this.dialogElement.textContent += text[index]; index++; }
      else { clearInterval(typeInterval); setTimeout(() => { if (this.dialogElement) this.dialogElement.style.opacity = '0'; }, duration * 1000); }
    }, 30);
  }
  capturePNG() {
    this.renderer.render(this.scene, this.camera);
    const dataURL = this.renderer.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `beuteltier-capture-${Date.now()}.png`;
    link.href = dataURL;
    link.click();
    return dataURL;
  }
  startRecording() {
    const stream = this.renderer.domElement.captureStream(30);
    this.mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    this.recordedChunks = [];
    this.mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) this.recordedChunks.push(e.data); };
    this.mediaRecorder.onstop = () => {
      const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `beuteltier-scene-${Date.now()}.webm`;
      link.href = url;
      link.click();
    };
    this.mediaRecorder.start();
  }
  stopRecording() { if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') this.mediaRecorder.stop(); }
  dispose() {
    if (this.dialogElement) { this.dialogElement.remove(); this.dialogElement = null; }
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') this.mediaRecorder.stop();
  }
}
