import * as THREE from 'three';

export const WORLD_STATE_KEYS = [
  'timeOfDay', 'dayOfYear', 'weather', 'temperature', 'humidity',
  'windSpeed', 'crowdDensity', 'eventPhase', 'blessing', 'pollution',
  'wear', 'npcMood', 'forbiddenZone',
];

export class ShadedWorldState {
  constructor() {
    this.state = {
      timeOfDay: 14.0, dayOfYear: 238, weather: 'clear',
      temperature: 22.0, humidity: 0.45, windSpeed: 2.5,
      crowdDensity: 0.3, eventPhase: 'open', blessing: 0.0,
      pollution: 0.1, wear: 0.0, npcMood: 0.6, forbiddenZone: 0.0,
    };
    this.listeners = new Set();
    this.materialRules = this.buildMaterialRules();
  }
  get(k) { return this.state[k]; }
  set(k, v) {
    if (this.state[k] !== v) { this.state[k] = v; this.listeners.forEach(cb => cb(k, v, this.state)); }
  }
  subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  buildMaterialRules() {
    return {
      wetness: {
        asphalt:  (h, t) => Math.min(1, h * 1.2 + (t < 0 ? 0.3 : 0)),
        grass:    (h, t) => Math.min(1, h * 0.6),
        concrete: (h, t) => Math.min(1, h * 0.4),
        floor:    (h, t) => Math.min(1, h * 0.8),
        cardboard:(h, t) => Math.min(1, h * 2.0),
        wood:     (h, t) => Math.min(1, h * 0.9 + this.state.wear * 0.5),
      },
      heatShimmer: {
        asphalt:  (temp) => temp > 28 ? (temp - 28) / 12 : 0,
        grass:    () => 0,
        floor:    (temp) => temp > 30 ? (temp - 30) / 10 : 0,
      },
      decay: {
        grass:    (w, wd) => w * 0.1 + wd * 0.05,
        wood:     (w, wd) => w * 0.8 + wd * 0.3,
        cardboard:(w, wd) => w * 1.5 + wd * 0.8,
        metal:    (w, wd) => w * 0.2 + wd * 0.1,
        concrete: (w, wd) => w * 0.05 + wd * 0.02,
        banner:   (w, wd) => w * 0.4 + wd * 0.2,
      },
      lightPollution: { led: (p) => p * 2.0, banner: (p) => p * 0.5, floor: (p) => p * 0.1 },
      moodTint: { all: (mood) => mood > 0.7 ? new THREE.Color(0xffeeaa) : mood < 0.3 ? new THREE.Color(0x6688aa) : new THREE.Color(0xffffff) },
      blessing: { bloom: (b) => 1.0 + b * 0.5, decay: (b) => Math.max(0, 1.0 - b * 0.8), tint: (b) => b > 0 ? new THREE.Color(0xfff8dd) : new THREE.Color(0x221133) },
    };
  }
  wetnessFor(mk) { const h = this.state.humidity, t = this.state.temperature; const r = this.materialRules.wetness[mk]; return r ? r(h, t) : h; }
  decayFor(mk) { const w = this.state.wear, wd = this.state.dayOfYear / 365; const r = this.materialRules.decay[mk]; return r ? Math.min(1, r(w, wd)) : 0; }
  heatShimmerFor(mk) { const r = this.materialRules.heatShimmer[mk]; return r ? r(this.state.temperature) : 0; }
  getMoodTint() { return this.materialRules.moodTint.all(this.state.npcMood); }
  getBlessingBloom() { return this.materialRules.blessing.bloom(this.state.blessing); }
  getBlessingTint() { return this.materialRules.blessing.tint(this.state.blessing); }
  getDayCycle() { return this.state.timeOfDay / 24; }
  isNight() { return this.state.timeOfDay < 6 || this.state.timeOfDay > 20; }
  getSunElevation() { const t = this.state.timeOfDay; if (t < 6 || t > 20) return -0.2; const noon = 13; const dist = Math.abs(t - noon); return Math.max(0, 1 - dist / 7); }
}
