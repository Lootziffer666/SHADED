import { useState, useCallback } from 'react';
import { LENS_MODES } from '../procedural/systems/ShadedOrchestrator';

interface ShadedControlsProps { shaded: any; }

const WEATHER_OPTIONS = ['clear', 'rain', 'storm', 'fog', 'snow'];
const PHASE_OPTIONS = ['setup', 'open', 'peak', 'winddown', 'closed'];
const LENS_OPTIONS = [
  { key: LENS_MODES.NORMAL, label: 'Normal' },
  { key: LENS_MODES.WEAR, label: 'Abnutzung' },
  { key: LENS_MODES.STRESS, label: 'Belastung' },
  { key: LENS_MODES.SOUND, label: 'Klangwellen' },
  { key: LENS_MODES.EDGE, label: 'Kanten' },
];

export function ShadedControls({ shaded }: ShadedControlsProps) {
  const [timeOfDay, setTimeOfDay] = useState(14);
  const [weather, setWeather] = useState('clear');
  const [blessing, setBlessing] = useState(0);
  const [wear, setWear] = useState(0);
  const [lens, setLens] = useState(LENS_MODES.NORMAL);
  const [recording, setRecording] = useState(false);

  const updateState = useCallback((key: string, value: any) => {
    if (!shaded) return;
    shaded.setState(key, value);
  }, [shaded]);

  const handleLens = useCallback((mode: string) => {
    if (!shaded) return;
    setLens(mode);
    shaded.setLens(mode);
  }, [shaded]);

  const toggleRecording = useCallback(() => {
    if (!shaded) return;
    if (recording) { shaded.stopRecording(); setRecording(false); }
    else { shaded.startRecording(); setRecording(true); }
  }, [shaded, recording]);

  const capture = useCallback(() => { if (shaded) shaded.capturePNG(); }, [shaded]);

  if (!shaded) return null;

  return (
    <div style={{ position: 'fixed', top: 16, right: 16, zIndex: 1000, background: 'rgba(0,0,0,0.8)', color: '#fff', padding: 16, borderRadius: 12, width: 280, fontFamily: 'system-ui, sans-serif', fontSize: 13, maxHeight: '90vh', overflowY: 'auto' }}>
      <h3 style={{ margin: '0 0 12px', fontSize: 16, borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: 8 }}>SHADED Welt-Simulation</h3>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', marginBottom: 4, opacity: 0.7 }}>Tageszeit: {timeOfDay.toFixed(1)}h</label>
        <input type="range" min={0} max={24} step={0.1} value={timeOfDay}
          onChange={e => { const v = parseFloat(e.target.value); setTimeOfDay(v); updateState('timeOfDay', v); }}
          style={{ width: '100%' }} />
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', marginBottom: 4, opacity: 0.7 }}>Wetter</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {WEATHER_OPTIONS.map(w => (
            <button key={w} onClick={() => { setWeather(w); updateState('weather', w); }}
              style={{ padding: '4px 8px', borderRadius: 4, border: 'none', background: weather === w ? '#4a90d9' : 'rgba(255,255,255,0.15)', color: '#fff', cursor: 'pointer', fontSize: 12 }}>
              {w}
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', marginBottom: 4, opacity: 0.7 }}>Segen / Fluch: {blessing > 0 ? '+' : ''}{blessing}</label>
        <input type="range" min={-1} max={1} step={0.05} value={blessing}
          onChange={e => { const v = parseFloat(e.target.value); setBlessing(v); updateState('blessing', v); }}
          style={{ width: '100%' }} />
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', marginBottom: 4, opacity: 0.7 }}>Abnutzung: {(wear * 100).toFixed(0)}%</label>
        <input type="range" min={0} max={1} step={0.01} value={wear}
          onChange={e => { const v = parseFloat(e.target.value); setWear(v); updateState('wear', v); }}
          style={{ width: '100%' }} />
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', marginBottom: 4, opacity: 0.7 }}>Inspektions-Linse</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {LENS_OPTIONS.map(l => (
            <button key={l.key} onClick={() => handleLens(l.key)}
              style={{ padding: '4px 8px', borderRadius: 4, border: 'none', background: lens === l.key ? '#d94a4a' : 'rgba(255,255,255,0.15)', color: '#fff', cursor: 'pointer', fontSize: 12 }}>
              {l.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
        <button onClick={capture} style={{ flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', background: '#4a90d9', color: '#fff', cursor: 'pointer', fontSize: 12 }}>📸 PNG</button>
        <button onClick={toggleRecording} style={{ flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', background: recording ? '#d94a4a' : '#4ad94a', color: '#fff', cursor: 'pointer', fontSize: 12 }}>{recording ? '⏹ Stop' : '⏺ WebM'}</button>
      </div>
    </div>
  );
}
