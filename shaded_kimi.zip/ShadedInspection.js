import * as THREE from 'three';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

export const LENS_MODES = { NORMAL: 'normal', WEAR: 'wear', STRESS: 'stress', SOUND: 'sound', EDGE: 'edge' };

export class ShadedInspection {
  constructor(composer, worldState) {
    this.composer = composer;
    this.world = worldState;
    this.currentLens = LENS_MODES.NORMAL;
    this.passes = new Map();
    this.initPasses();
  }
  initPasses() {
    this.passes.set(LENS_MODES.WEAR, new ShaderPass({
      uniforms: { tDiffuse: { value: null }, intensity: { value: 1.0 } },
      vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform sampler2D tDiffuse; uniform float intensity; varying vec2 vUv; void main() { vec4 texel = texture2D(tDiffuse, vUv); float wear = 1.0 - texel.g; vec3 wearColor = mix(texel.rgb, vec3(1.0, 0.2, 0.1), wear * intensity * 0.7); gl_FragColor = vec4(wearColor, texel.a); }`
    }));
    this.passes.set(LENS_MODES.STRESS, new ShaderPass({
      uniforms: { tDiffuse: { value: null }, crowdDensity: { value: 0.3 } },
      vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform sampler2D tDiffuse; uniform float crowdDensity; varying vec2 vUv; void main() { vec4 texel = texture2D(tDiffuse, vUv); vec3 stressColor = mix(texel.rgb, vec3(1.0, 0.6, 0.0), crowdDensity * 0.5); gl_FragColor = vec4(stressColor, texel.a); }`
    }));
    this.passes.set(LENS_MODES.SOUND, new ShaderPass({
      uniforms: { tDiffuse: { value: null }, time: { value: 0 } },
      vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform sampler2D tDiffuse; uniform float time; varying vec2 vUv; void main() { vec4 texel = texture2D(tDiffuse, vUv); float wave = sin(distance(vUv, vec2(0.5)) * 20.0 - time * 4.0) * 0.5 + 0.5; vec3 waveColor = mix(texel.rgb, vec3(0.2, 0.8, 1.0), wave * 0.15); gl_FragColor = vec4(waveColor, texel.a); }`
    }));
    this.passes.set(LENS_MODES.EDGE, new ShaderPass({
      uniforms: { tDiffuse: { value: null }, resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) } },
      vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 resolution; varying vec2 vUv; void main() { vec2 texel = vec2(1.0 / resolution.x, 1.0 / resolution.y); vec4 c = texture2D(tDiffuse, vUv); vec4 l = texture2D(tDiffuse, vUv - vec2(texel.x, 0.0)); vec4 r = texture2D(tDiffuse, vUv + vec2(texel.x, 0.0)); vec4 t = texture2D(tDiffuse, vUv + vec2(0.0, texel.y)); vec4 b = texture2D(tDiffuse, vUv - vec2(0.0, texel.y)); vec4 edge = abs(l - r) + abs(t - b); float edgeVal = length(edge.rgb); vec3 edgeColor = mix(vec3(0.0), vec3(1.0), step(0.1, edgeVal)); gl_FragColor = vec4(edgeColor, 1.0); }`
    }));
  }
  setLens(mode) {
    if (this.currentLens === mode) return;
    const oldPass = this.passes.get(this.currentLens);
    if (oldPass && this.composer.passes.includes(oldPass)) this.composer.removePass(oldPass);
    const newPass = this.passes.get(mode);
    if (newPass && mode !== LENS_MODES.NORMAL) this.composer.insertPass(newPass, this.composer.passes.length - 1);
    this.currentLens = mode;
  }
  update(time) {
    const sp = this.passes.get(LENS_MODES.SOUND);
    if (sp) sp.uniforms.time.value = time;
    const stp = this.passes.get(LENS_MODES.STRESS);
    if (stp) stp.uniforms.crowdDensity.value = this.world.get('crowdDensity');
  }
  dispose() {
    this.passes.forEach(pass => { if (this.composer.passes.includes(pass)) this.composer.removePass(pass); });
  }
}
