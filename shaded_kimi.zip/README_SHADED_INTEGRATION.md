# SHADED → BEUTELTIER Integration

## Was ist neu

Dieser Branch fügt 8 neue Systeme in die prozedurale Pipeline ein,
die alle auf 13 gemeinsamen Zustandsparametern arbeiten:

| System | Datei | SHADED-Feature |
|--------|-------|----------------|
| Welt-Zustand | `ShadedWorldState.js` | 13 Parameter + materialabhängige Regeln |
| Hydrologie | `ShadedHydrology.js` | Regen, Pfützen, Verdunstung, Tropfkanten |
| Wetter | `ShadedWeather.js` | Sturm, Blitz, Nebel, Rauch, Wind |
| Jahreszeiten | `ShadedSeasons.js` | Schnee, Herbstfärbung, Sonnenbleiche |
| Materialverhalten | `ShadedMaterialBehavior.js` | Nässe, Rost, Moos, Brandspuren |
| Interaktion | `ShadedInteraction.js` | Fußspuren, Trampelpfade, aufgewirbeltes Laub |
| Inspektion | `ShadedInspection.js` | 5 umschaltbare Linsen (Wear, Stress, Sound, Edge) |
| Narrative | `ShadedNarrative.js` | Storyboard, Dialoge, PNG/WebM-Aufnahme |
| Orchestrator | `ShadedOrchestrator.js` | Zentrale Steuerung aller Systeme |
| UI | `ShadedControls.tsx` | React-Overlay für Live-Steuerung |

## Dateien kopieren

```
app/src/procedural/systems/
  ShadedWorldState.js
  ShadedHydrology.js
  ShadedWeather.js
  ShadedSeasons.js
  ShadedMaterialBehavior.js
  ShadedInteraction.js
  ShadedInspection.js
  ShadedNarrative.js
  ShadedOrchestrator.js

app/src/ui/
  ShadedControls.tsx
```

## Patches anwenden

Siehe `PATCH_main.js.txt` und `PATCH_SiteScene.tsx.txt`.

## Besondere SHADED-Features in BEUTELTIER

- **Druck und Gewicht**: Hohe crowdDensity verdunkelt belastete Bodenbereiche.
- **NPC-Stimmung**: Färbt die Welt atmosphärisch warm (euphorisch) oder kalt (müde).
- **Segen/Fluch**: Verändert Bloom, Helligkeit und Verfall global.
- **Verbotene Bereiche**: Kalte Grenzreaktion über `forbiddenZone`.
- **Lichtverschmutzung**: LED-Wände und Banner beeinflussen die Umgebung.
- **Hitze-Schimmer**: Über Asphalt bei >28°C.
- **Schneedellen**: Spieler hinterlässt Eindrücke im Schnee.
- **Lagerfeuer**: Werden bei Regen gelöscht.
- **Trampelpfade**: Entstehen durch wiederholtes Laufen auf gleicher Stelle.
