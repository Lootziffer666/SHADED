import * as THREE from 'three';

export class ShadedHydrology {
  constructor(scene, worldState) {
    this.scene = scene;
    this.world = worldState;
    this.puddles = [];
    this.initRainSystem();
    this.initPuddleSystem();
  }
  initRainSystem() {
    const count = 4000;
    const geom = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 120;
      positions[i * 3 + 1] = 15 + Math.random() * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 120;
      velocities[i] = 8 + Math.random() * 4;
    }
    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.rainGeom = geom;
    this.rainVel = velocities;
    this.rainMesh = new THREE.Points(geom, new THREE.PointsMaterial({
      color: 0xaaccff, size: 0.06, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true
    }));
    this.scene.add(this.rainMesh);
  }
  initPuddleSystem() {
    const puddleGeom = new THREE.CircleGeometry(1, 16);
    const puddleMat = new THREE.MeshPhysicalMaterial({
      color: 0x223344, metalness: 0.1, roughness: 0.05, transmission: 0.6,
      thickness: 0.1, transparent: true, opacity: 0, clearcoat: 1.0, clearcoatRoughness: 0.1,
    });
    this.puddleMat = puddleMat;
    this.puddleGeom = puddleGeom;
  }
  spawnPuddle(x, z, radius) {
    const mesh = new THREE.Mesh(this.puddleGeom, this.puddleMat.clone());
    mesh.position.set(x, 0.02, z);
    mesh.scale.set(radius, radius, 1);
    mesh.rotation.x = -Math.PI / 2;
    mesh.userData = { maxRadius: radius, currentRadius: 0, life: 0 };
    this.scene.add(mesh);
    this.puddles.push(mesh);
  }
  update(delta, time) {
    const weather = this.world.get('weather');
    const isRaining = weather === 'rain' || weather === 'storm';
    const temp = this.world.get('temperature');
    this.rainMesh.material.opacity = isRaining ? (weather === 'storm' ? 0.7 : 0.4) : 0;
    if (isRaining) {
      const pos = this.rainGeom.attributes.position.array;
      for (let i = 0; i < pos.length / 3; i++) {
        pos[i * 3 + 1] -= this.rainVel[i] * delta;
        if (pos[i * 3 + 1] < 0) {
          if (Math.random() < 0.02 && this.puddles.length < 30) {
            this.spawnPuddle(pos[i * 3], pos[i * 3 + 2], 0.3 + Math.random() * 0.8);
          }
          pos[i * 3 + 1] = 15 + Math.random() * 10;
          pos[i * 3] = (Math.random() - 0.5) * 120;
          pos[i * 3 + 2] = (Math.random() - 0.5) * 120;
        }
      }
      this.rainGeom.attributes.position.needsUpdate = true;
    }
    this.puddles.forEach((p, idx) => {
      const data = p.userData;
      if (isRaining) {
        data.currentRadius = Math.min(data.maxRadius, data.currentRadius + delta * 0.1);
        data.life += delta;
      } else {
        const evapRate = 0.02 * (1 + Math.max(0, temp - 20) / 10);
        data.currentRadius -= evapRate * delta;
      }
      p.scale.set(data.currentRadius, data.currentRadius, 1);
      p.material.opacity = Math.min(0.7, data.currentRadius / data.maxRadius * 0.7);
      if (data.currentRadius <= 0.01) {
        this.scene.remove(p); p.geometry.dispose(); p.material.dispose(); this.puddles.splice(idx, 1);
      }
    });
  }
  dispose() {
    this.scene.remove(this.rainMesh); this.rainGeom.dispose(); this.rainMesh.material.dispose();
    this.puddles.forEach(p => { this.scene.remove(p); p.material.dispose(); });
    this.puddles = [];
  }
}
